import"./index-BxQnvICo.js";function r(r,t){return"string"==typeof r?t:r}export{r};
