import"./index-z45KPqVy.js";function r(r,t){return"string"==typeof r?t:r}export{r};
